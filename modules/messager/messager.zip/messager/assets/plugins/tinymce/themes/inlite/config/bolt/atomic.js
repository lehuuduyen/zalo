configure({
  configs: [
    './prod.js'
  ]
});
